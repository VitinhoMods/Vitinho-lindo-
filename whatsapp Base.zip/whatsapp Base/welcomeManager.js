const fs = require('fs');
const path = require('path');

// Caminho para o arquivo que vai armazenar as mensagens de boas-vindas personalizadas
const welcomeConfigPath = path.join(__dirname, 'welcomeConfig.json');

// Inicializa o arquivo de configuração se não existir
function initWelcomeConfig() {
  if (!fs.existsSync(welcomeConfigPath)) {
    fs.writeFileSync(
      welcomeConfigPath, 
      JSON.stringify({ 
        groups: {} 
      }, null, 2)
    );
  }
  return JSON.parse(fs.readFileSync(welcomeConfigPath, 'utf8'));
}

// Salva a configuração no arquivo
function saveWelcomeConfig(config) {
  fs.writeFileSync(welcomeConfigPath, JSON.stringify(config, null, 2));
}

// Obtém a mensagem de boas-vindas para um grupo específico
function getWelcomeMessage(groupId) {
  const config = initWelcomeConfig();
  return (config.groups[groupId]?.welcomeMessage) || 
    "Olá {nome}, seja bem-vindo(a) ao {grupo}! Siga as regras ou use o comando /rules para ver as regras do grupo.";
}

// Define uma nova mensagem de boas-vindas para um grupo
function setWelcomeMessage(groupId, message) {
  const config = initWelcomeConfig();
  
  if (!config.groups[groupId]) {
    config.groups[groupId] = {};
  }
  
  config.groups[groupId].welcomeMessage = message;
  saveWelcomeConfig(config);
  return true;
}

// Envia uma mensagem privada para o usuário solicitando a mensagem de boas-vindas
async function requestWelcomeMessage(sock, userJid, groupJid, groupName) {
  await sock.sendMessage(
    userJid, 
    { 
      text: `Olá! Você solicitou alterar a mensagem de boas-vindas para o grupo "${groupName}". 
      
Por favor, envie a nova mensagem de boas-vindas.

Você pode usar:
{nome} - para incluir o nome do novo membro
{grupo} - para incluir o nome do grupo

Exemplo: "Olá {nome}, seja bem-vindo(a) ao {grupo}! Siga as regras ou use /rules para ver as regras."` 
    }
  );
  
  // Retorna true para indicar que a mensagem foi enviada com sucesso
  return true;
}

// Processa a mensagem de boas-vindas quando um novo membro entra no grupo
async function handleGroupParticipantJoin(sock, groupEvent) {
  try {
    const { id: groupId, participants, action } = groupEvent;
    
    // Ignora se não for uma adição de participante
    if (action !== 'add') return;
    
    // Obtém metadados do grupo para conseguir o nome
    const groupMetadata = await sock.groupMetadata(groupId);
    const groupName = groupMetadata.subject;
    
    // Para cada novo participante
    for (const participantId of participants) {
      try {
        // Obtém informações do participante
        let userName = '';
        try {
          // Tenta obter o nome do usuário a partir do metadata
          const [userMetadata] = await sock.onWhatsApp(participantId);
          if (userMetadata?.exists) {
            // Tenta buscar informações de contato, se disponíveis
            const contact = await sock.getContact(participantId);
            userName = contact?.name || contact?.notify || userMetadata.jid.split('@')[0];
          } else {
            userName = participantId.split('@')[0];
          }
        } catch (err) {
          console.error('Erro ao obter informações do usuário:', err);
          userName = participantId.split('@')[0];
        }
        
        // Obtém a mensagem de boas-vindas e substitui os placeholders
        let welcomeMessage = getWelcomeMessage(groupId)
          .replace(/{nome}/g, userName)
          .replace(/{grupo}/g, groupName);
        
        // Tenta obter a foto de perfil do usuário
        let profilePictureUrl;
        try {
          profilePictureUrl = await sock.profilePictureUrl(participantId, 'image');
        } catch (err) {
          console.log('Não foi possível obter a foto de perfil do usuário');
          profilePictureUrl = null;
        }
        
        // Envia a mensagem de boas-vindas com a foto
        if (profilePictureUrl) {
          await sock.sendMessage(
            groupId, 
            {
              image: { url: profilePictureUrl },
              caption: welcomeMessage,
              mentions: [participantId]
            }
          );
        } else {
          // Sem foto, envia apenas texto
          await sock.sendMessage(
            groupId, 
            {
              text: welcomeMessage,
              mentions: [participantId]
            }
          );
        }
      } catch (error) {
        console.error(`Erro ao processar boas-vindas para ${participantId}:`, error);
      }
    }
  } catch (error) {
    console.error('Erro ao processar evento de participante:', error);
  }
}

// Gerencia o comando de configuração de boas-vindas
async function handleWelcomeCommand(sock, msg) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  
  // Verifica se é um grupo
  if (!jid.endsWith('@g.us')) {
    await sock.sendMessage(jid, { text: "Este comando só pode ser usado em grupos." });
    return;
  }
  
  // Verifica se o usuário é administrador
  const groupMetadata = await sock.groupMetadata(jid);
  const isAdmin = groupMetadata.participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .some(p => p.id === sender);
  
  if (!isAdmin) {
    await sock.sendMessage(jid, { text: "Apenas administradores podem configurar a mensagem de boas-vindas." });
    return;
  }
  
  // Envia mensagem privada para o usuário solicitando a mensagem de boas-vindas
  const result = await requestWelcomeMessage(sock, sender, jid, groupMetadata.subject);
  
  if (result) {
    await sock.sendMessage(jid, { 
      text: "Enviamos uma mensagem privada para você configurar a mensagem de boas-vindas.",
      mentions: [sender]
    });
  } else {
    await sock.sendMessage(jid, { 
      text: "Houve um erro ao processar seu pedido. Por favor, tente novamente.",
      mentions: [sender]
    });
  }
}

// Gerencia a resposta do usuário com a mensagem de boas-vindas
async function handleWelcomeMessageResponse(sock, msg, pendingWelcomeRequests) {
  const jid = msg.key.remoteJid;
  const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
  
  // Verifica se este usuário tem uma solicitação pendente
  const pendingRequest = pendingWelcomeRequests.find(req => req.userJid === jid);
  
  if (!pendingRequest) return false;
  
  // Define a nova mensagem de boas-vindas
  setWelcomeMessage(pendingRequest.groupJid, text);
  
  // Informa ao usuário que a mensagem foi configurada
  await sock.sendMessage(jid, { 
    text: "Mensagem de boas-vindas configurada com sucesso!" 
  });
  
  // Informa ao grupo que a mensagem foi configurada
  await sock.sendMessage(pendingRequest.groupJid, { 
    text: "A mensagem de boas-vindas foi atualizada com sucesso.",
    mentions: [jid]
  });
  
  // Remove esta solicitação da lista de pendentes
  const index = pendingWelcomeRequests.indexOf(pendingRequest);
  pendingWelcomeRequests.splice(index, 1);
  
  return true;
}

module.exports = {
  handleGroupParticipantJoin,
  handleWelcomeCommand,
  handleWelcomeMessageResponse,
  getWelcomeMessage,
  setWelcomeMessage
};